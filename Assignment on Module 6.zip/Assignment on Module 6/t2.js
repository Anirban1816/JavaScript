{
  console.log('\n--- Task 2 ---');
  let numbers = [10, 20, 30, 40, 50];

  // map() for transformation
  let incrementedNumbers = numbers.map(num => num + 10);
  console.log('Incremented Numbers:', incrementedNumbers);

  // filter() for filtering
  let filteredNumbers = numbers.filter(num => num > 30);
  console.log('Numbers greater than 30:', filteredNumbers);
}
