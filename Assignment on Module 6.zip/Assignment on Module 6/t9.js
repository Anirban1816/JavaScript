{
  console.log('--- Task 9 ---');

  class Person {
    introduce() {
      console.log('I am a person.');
    }
  }

  // Child Class
  class Student extends Person {
    introduce() {
      console.log('I am a student and I love learning new technologies.');
    }
  }

  let personObj = new Person();
  let studentObj = new Student();

  personObj.introduce();
  studentObj.introduce();
}
