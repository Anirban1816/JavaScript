{
  console.log('--- Task 8 ---');
  class Student {
    constructor(name, age, course) {
      this.name = name;
      this.age = age;
      this.course = course;
    }
  }

  let student1 = new Student('Rahim', 22, 'JavaScript');
  let student2 = new Student('Karim', 23, 'React');

  console.log('Student 1:', student1);
  console.log('Student 2:', student2);
}
