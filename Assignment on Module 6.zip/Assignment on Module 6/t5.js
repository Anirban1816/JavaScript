{
  console.log('--- Task 5 ---');
  let numbersSet = new Set([10, 20, 30]);

  // add()
  numbersSet.add(40);

  // delete()
  numbersSet.delete(20);

  // has()
  console.log('Has 30?:', numbersSet.has(30));

  // forEach()
  numbersSet.forEach(value => {
    console.log('Set Value:', value);
  });
}
