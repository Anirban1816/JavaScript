{
  console.log('--- Task 3 ---');
  let marks = [40, 55, 70, 85, 30];

  // reduce()
  let totalMarks = marks.reduce((sum, mark) => sum + mark, 0);
  console.log('Total Marks:', totalMarks);

  // find()
  let firstHighMark = marks.find(mark => mark >= 70);
  console.log('First mark >= 70:', firstHighMark);

  // findIndex()
  let indexOf85 = marks.findIndex(mark => mark === 85);
  console.log('Index of 85:', indexOf85);
}
