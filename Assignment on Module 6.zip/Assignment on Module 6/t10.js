{
  console.log('--- Task 10 (OOP Project with Bonus) ---');
  class BankAccount {
    constructor(name, balance) {
      this.name = name;
      this.balance = balance;
    }

    // Deposit method
    deposit(amount) {
      this.balance += amount;
      console.log(`Successfully deposited: $${amount}`);
    }

    // Withdraw method
    withdraw(amount) {
      if (amount <= this.balance) {
        this.balance -= amount;
        console.log(`Successfully withdrew: $${amount}`);
      } else {
        console.log('Insufficient balance!');
      }
    }

    // Bonus: static method
    static getBankName() {
      return 'Trust Bank Limited';
    }
  }

  // static method
  console.log('Bank Name (Static):', BankAccount.getBankName());

  // Object creation
  let account = new BankAccount('Rahim', 5000);

  // Transactions
  account.deposit(1000);
  account.withdraw(500);

  console.log(`Account Holder: ${account.name}`);
  console.log(`Current Balance: $${account.balance}`);
}
