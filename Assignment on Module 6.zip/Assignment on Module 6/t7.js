{
  console.log('--- Task 7 ---');
  // Spread
  let a = [1, 2, 3];
  let b = [4, 5, 6];

  let combinedArray = [...a, ...b];
  console.log('Combined Array:', combinedArray);

  // Rest
  function sum(...numbers) {
    return numbers.reduce((acc, curr) => acc + curr, 0);
  }

  console.log('Sum (10, 20, 30):', sum(10, 20, 30));
}
