{
  console.log('--- Task 1 ---');
  let fruits = ['Apple', 'Mango', 'Banana'];

  // push() for addition
  fruits.push('Orange');

  // pop() for remove items
  fruits.pop();

  // forEach() to show every item of the array
  fruits.forEach(function (fruit) {
    console.log(fruit);
  });
}
