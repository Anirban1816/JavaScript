{
  console.log('--- Task 6 ---');
  let studentMap = new Map();

  // set()
  studentMap.set('name', 'Rahim');
  studentMap.set('age', 22);

  // get()
  console.log('Student Name:', studentMap.get('name'));

  // has()
  console.log("Has 'age'?:", studentMap.has('age'));

  // size
  console.log('Map Size:', studentMap.size);
}
